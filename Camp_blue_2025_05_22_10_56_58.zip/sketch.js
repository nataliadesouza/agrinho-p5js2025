function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let seeds = [];
let plants = [];
let harvests = 0;

function setup() {
  createCanvas(600, 400);
  textSize(16);
}

function draw() {
  background(200, 230, 200);
  
  // Instruções
  fill(0);
  text("Clique para plantar uma semente", 10, 20);
  text("Pressione 'H' para colher uma planta madura", 10, 40);
  text("Colheitas: " + harvests, 10, 60);
  
  // Desenhar o solo
  fill(139, 69, 19);
  rect(0, height - 50, width, 50);
  
  // Desenhar sementes
  for (let seed of seeds) {
    fill(255, 255, 0);
    ellipse(seed.x, seed.y, 10, 10);
  }
  
  // Crescer e desenhar plantas
  for (let i = plants.length - 1; i >= 0; i--) {
    let plant = plants[i];
    if (plant.size < 50) {
      plant.size += 0.5; // Crescimento
    } else {
      plant.mature = true;
    }
    fill(34, 139, 34);
    rect(plant.x - 5, plant.y - plant.size, 10, plant.size);
  }
}

function mousePressed() {
  // Plantar uma semente na posição do mouse
  if (mouseY > height - 50) {
    seeds.push({ x: mouseX, y: mouseY - 5 });
  }
}

function keyPressed() {
  // Colher uma planta madura ao pressionar 'H'
  if (key === 'H' || key === 'h') {
    for (let i = plants.length - 1; i >= 0; i--) {
      let plant = plants[i];
      if (plant.mature) {
        harvests++;
        plants.splice(i, 1); // Remove a planta colhida
        break; // Colhe uma por vez
      }
    }
  }
}

// Detectar sementes e transformar em plantas
function keyReleased() {
  // Quando uma semente estiver na terra, ela vira uma planta
  for (let i = seeds.length - 1; i >= 0; i--) {
    let seed = seeds[i];
    if (seed.y >= height - 50) {
      plants.push({ x: seed.x, y: height - 50, size: 10, mature: false });
      seeds.splice(i, 1);
    }
  }
}